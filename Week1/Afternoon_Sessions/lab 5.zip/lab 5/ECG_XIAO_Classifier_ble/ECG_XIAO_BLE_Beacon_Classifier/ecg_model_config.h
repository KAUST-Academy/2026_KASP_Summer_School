#pragma once

constexpr int ECG_SAMPLE_RATE_HZ = 250;
constexpr int ECG_WINDOW_SIZE = 200;
constexpr int ECG_CLASS_COUNT = 4;
constexpr float ECG_INPUT_SCALE = 0.007843137719f;
constexpr int ECG_INPUT_ZERO_POINT = -1;
constexpr float ECG_OUTPUT_SCALE = 0.00390625f;
constexpr int ECG_OUTPUT_ZERO_POINT = -128;

constexpr const char* ECG_CLASS_LABELS[ECG_CLASS_COUNT] = {"N", "S", "V", "F"};
