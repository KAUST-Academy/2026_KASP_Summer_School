/*
  XIAO ESP32S3 BLE ECG Receiver

  Receives BLE manufacturer data from the transmitter named:

      ECG-XIAO

  Expected transmitter packet:
    Byte 0-1:  Company ID = 0xFFFF
    Byte 2-4:  Magic text = 'E', 'C', 'G'
    Byte 5:    Protocol version = 1
    Byte 6:    Status
                 0 = Not detected
                 1 = Detected
                 2 = Calibrating
    Byte 7:    ECG class
                 0 = N, Normal-type
                 1 = S, Supraventricular
                 2 = V, Ventricular
                 3 = F, Fusion
                 4 = Q, Paced/Unknown
               255 = No class
    Byte 8:    Confidence, 0-100%
    Byte 9:    Estimated heart rate, BPM
    Byte 10-11: Sequence number, little endian

  Arduino IDE:
    Board: Seeed Studio XIAO ESP32S3
    USB CDC On Boot: Enabled
    Serial Monitor: 115200 baud

  Uses the ESP32 BLE library included with the ESP32 board package.
  No NimBLE library is required.
*/

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>

// ====================================================
// Expected transmitter identity and packet settings
// ====================================================

const char* TARGET_DEVICE_NAME = "ECG-XIAO";

const uint16_t EXPECTED_COMPANY_ID = 0xFFFF;
const uint8_t EXPECTED_PROTOCOL_VERSION = 1;
const uint8_t EXPECTED_PACKET_LENGTH = 12;

const uint32_t SCAN_TIME_SECONDS = 4;

BLEScan* pBLEScan = nullptr;

bool targetFound = false;
bool validPacketFound = false;
bool havePreviousPacket = false;
uint16_t previousSequenceNumber = 0;

// ====================================================
// ECG protocol values
// ====================================================

enum EcgStatus : uint8_t
{
  ECG_NOT_DETECTED = 0,
  ECG_DETECTED = 1,
  ECG_CALIBRATING = 2
};

// ====================================================
// Helpers
// ====================================================

const char* statusName(uint8_t status)
{
  if (status == ECG_NOT_DETECTED) return "NOT DETECTED";
  if (status == ECG_DETECTED) return "DETECTED";
  if (status == ECG_CALIBRATING) return "CALIBRATING";
  return "UNKNOWN";
}

const char* classCode(uint8_t classIndex)
{
  if (classIndex == 0) return "N";
  if (classIndex == 1) return "S";
  if (classIndex == 2) return "V";
  if (classIndex == 3) return "F";
  if (classIndex == 4) return "Q";
  return "-";
}

const char* className(uint8_t classIndex)
{
  if (classIndex == 0) return "Normal-type";
  if (classIndex == 1) return "Supraventricular";
  if (classIndex == 2) return "Ventricular";
  if (classIndex == 3) return "Fusion";
  if (classIndex == 4) return "Paced/Unknown";
  return "No class";
}

bool validClassIndex(uint8_t classIndex)
{
  return classIndex <= 4 || classIndex == 255;
}

void blinkStartupLED()
{
  // XIAO ESP32S3 onboard yellow LED is active LOW.
  pinMode(LED_BUILTIN, OUTPUT);

  for (int i = 0; i < 3; i++)
  {
    digitalWrite(LED_BUILTIN, LOW);
    delay(150);
    digitalWrite(LED_BUILTIN, HIGH);
    delay(150);
  }
}

void printRawPacket(const uint8_t* data, int length)
{
  Serial.print("Raw manufacturer data: ");

  for (int i = 0; i < length; i++)
  {
    if (data[i] < 0x10)
    {
      Serial.print('0');
    }

    Serial.print(data[i], HEX);

    if (i < length - 1)
    {
      Serial.print(' ');
    }
  }

  Serial.println();
}

// ====================================================
// Decode and display ECG packet
// ====================================================

void decodeEcgPacket(
  BLEAdvertisedDevice& device,
  const String& receivedName,
  const uint8_t* data,
  int packetLength
)
{
  if (packetLength < EXPECTED_PACKET_LENGTH)
  {
    Serial.print("ECG packet is too short: ");
    Serial.print(packetLength);
    Serial.println(" bytes");
    printRawPacket(data, packetLength);
    return;
  }

  uint16_t companyID =
    (uint16_t)data[0] |
    ((uint16_t)data[1] << 8);

  char magicE = (char)data[2];
  char magicC = (char)data[3];
  char magicG = (char)data[4];

  uint8_t protocolVersion = data[5];
  uint8_t status = data[6];
  uint8_t classIndex = data[7];
  uint8_t confidence = data[8];
  uint8_t bpm = data[9];

  uint16_t sequenceNumber =
    (uint16_t)data[10] |
    ((uint16_t)data[11] << 8);

  // Confirm that this is the ECG packet produced by our XIAO transmitter.
  if (companyID != EXPECTED_COMPANY_ID)
  {
    return;
  }

  if (magicE != 'E' || magicC != 'C' || magicG != 'G')
  {
    return;
  }

  if (protocolVersion != EXPECTED_PROTOCOL_VERSION)
  {
    Serial.print("Unsupported ECG protocol version: ");
    Serial.println(protocolVersion);
    return;
  }

  if (status > ECG_CALIBRATING)
  {
    Serial.print("Invalid ECG status: ");
    Serial.println(status);
    return;
  }

  if (!validClassIndex(classIndex))
  {
    Serial.print("Invalid ECG class index: ");
    Serial.println(classIndex);
    return;
  }

  validPacketFound = true;

  // The same beacon update is advertised many times. Print only new updates.
  if (havePreviousPacket &&
      sequenceNumber == previousSequenceNumber)
  {
    return;
  }

  havePreviousPacket = true;
  previousSequenceNumber = sequenceNumber;

  Serial.println();
  Serial.println("========================================");
  Serial.print("Module: ");
  Serial.println(receivedName);

  Serial.print("Address: ");
  Serial.println(device.getAddress().toString().c_str());

  Serial.print("RSSI: ");
  Serial.print(device.getRSSI());
  Serial.println(" dBm");

  Serial.print("Packet number: ");
  Serial.println(sequenceNumber);

  Serial.print("Status: ");
  Serial.println(statusName(status));

  if (status == ECG_CALIBRATING)
  {
    Serial.println("The XIAO is calibrating the R-peak detector.");
  }
  else if (status == ECG_NOT_DETECTED)
  {
    Serial.println("No valid ECG classification was detected.");
  }
  else if (status == ECG_DETECTED)
  {
    Serial.print("Class code: ");
    Serial.println(classCode(classIndex));

    Serial.print("Classification: ");
    Serial.println(className(classIndex));

    Serial.print("Confidence: ");
    Serial.print(confidence);
    Serial.println("%");

    if (bpm > 0)
    {
      Serial.print("Estimated heart rate: ");
      Serial.print(bpm);
      Serial.println(" BPM");
    }
    else
    {
      Serial.println("Estimated heart rate: unavailable");
    }
  }

  printRawPacket(data, packetLength);
  Serial.println("========================================");
}

// ====================================================
// BLE callback
// ====================================================

class EcgReceiverCallbacks : public BLEAdvertisedDeviceCallbacks
{
  void onResult(BLEAdvertisedDevice device) override
  {
    String receivedName = "";

    if (device.haveName())
    {
      receivedName = device.getName();
    }

    bool nameMatches =
      receivedName == TARGET_DEVICE_NAME;

    // Active scanning normally returns the ECG-XIAO name from the scan
    // response. However, also accept a packet by its ECG manufacturer magic
    // so the receiver still works if a BLE stack omits the local name.
    bool manufacturerLooksLikeEcg = false;

    if (device.haveManufacturerData())
    {
      String manufacturerData = device.getManufacturerData();

      if (manufacturerData.length() >= EXPECTED_PACKET_LENGTH)
      {
        const uint8_t* data =
          reinterpret_cast<const uint8_t*>(
            manufacturerData.c_str()
          );

        uint16_t companyID =
          (uint16_t)data[0] |
          ((uint16_t)data[1] << 8);

        manufacturerLooksLikeEcg =
          companyID == EXPECTED_COMPANY_ID &&
          data[2] == 'E' &&
          data[3] == 'C' &&
          data[4] == 'G';
      }
    }

    if (!nameMatches && !manufacturerLooksLikeEcg)
    {
      return;
    }

    targetFound = true;

    if (receivedName.length() == 0)
    {
      receivedName = TARGET_DEVICE_NAME;
    }

    if (!device.haveManufacturerData())
    {
      Serial.println(
        "ECG-XIAO found, but manufacturer data is not present yet."
      );
      return;
    }

    String manufacturerData = device.getManufacturerData();

    const uint8_t* data =
      reinterpret_cast<const uint8_t*>(
        manufacturerData.c_str()
      );

    decodeEcgPacket(
      device,
      receivedName,
      data,
      manufacturerData.length()
    );
  }
};

// ====================================================
// Setup
// ====================================================

void setup()
{
  Serial.begin(115200);

  // Give the native USB serial port time to appear.
  delay(3000);

  blinkStartupLED();

  Serial.println();
  Serial.println("========================================");
  Serial.println("XIAO ESP32S3 BLE ECG Receiver");
  Serial.print("Target module name: ");
  Serial.println(TARGET_DEVICE_NAME);
  Serial.println("========================================");

  Serial.println("Starting BLE...");

  BLEDevice::init("");

  pBLEScan = BLEDevice::getScan();

  // Active scan is important because ECG-XIAO places its local name in the
  // scan-response packet.
  pBLEScan->setActiveScan(true);

  // true allows repeated packets. The sequence number removes duplicates.
  pBLEScan->setAdvertisedDeviceCallbacks(
    new EcgReceiverCallbacks(),
    true
  );

  pBLEScan->setInterval(100);
  pBLEScan->setWindow(99);

  Serial.println("BLE scanner started.");
}

// ====================================================
// Main loop
// ====================================================

void loop()
{
  targetFound = false;
  validPacketFound = false;

  Serial.println();
  Serial.println("Scanning for ECG-XIAO...");

  BLEScanResults* results =
    pBLEScan->start(SCAN_TIME_SECONDS, false);

  Serial.print("Total BLE devices seen: ");
  Serial.println(results->getCount());

  if (!targetFound)
  {
    Serial.println("ECG-XIAO was not detected in this scan.");
  }
  else if (!validPacketFound)
  {
    Serial.println(
      "ECG-XIAO was seen, but no valid ECG manufacturer packet was decoded."
    );
  }

  pBLEScan->clearResults();

  delay(500);
}
