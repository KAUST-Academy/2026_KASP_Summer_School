#include <Adafruit_TinyUSB.h>

#define ECG_PIN A0   // AD8232 OUTPUT connected to XIAO D0/A0

const unsigned long SAMPLE_INTERVAL_US = 4000;  // 250 samples/second

unsigned long previousSampleTime = 0;

// Five-sample moving average reduces 50 Hz interference
const int FILTER_SIZE = 5;
int sampleBuffer[FILTER_SIZE] = {0, 0, 0, 0, 0};

long sampleTotal = 0;
int bufferIndex = 0;
bool filterReady = false;

void setup() {
  Serial.begin(115200);

  analogReadResolution(12);

  delay(1000);
}

void loop() {
  unsigned long currentTime = micros();

  if (currentTime - previousSampleTime >= SAMPLE_INTERVAL_US) {
    previousSampleTime += SAMPLE_INTERVAL_US;

    int rawECG = analogRead(ECG_PIN);

    // Remove the oldest sample
    sampleTotal -= sampleBuffer[bufferIndex];

    // Add the newest sample
    sampleBuffer[bufferIndex] = rawECG;
    sampleTotal += rawECG;

    bufferIndex++;

    if (bufferIndex >= FILTER_SIZE) {
      bufferIndex = 0;
      filterReady = true;
    }

    int filteredECG;

    if (filterReady) {
      filteredECG = sampleTotal / FILTER_SIZE;
    } else {
      filteredECG = rawECG;
    }

    // Display both signals in Arduino Serial Plotter
    Serial.print("Raw:");
    Serial.print(rawECG);

    Serial.print("\tFiltered:");
    Serial.println(filteredECG);
  }
}