#include <Adafruit_LSM6DS3TRC.h>
#include <Wire.h>

// Fallback definition for the power pin in case the board package is outdated
#ifndef PIN_LSM6DS3TR_C_POWER
#define PIN_LSM6DS3TR_C_POWER 14
#endif

// Create the sensor object
Adafruit_LSM6DS3TRC lsm6ds;

void setup() {
  Serial.begin(115200);
  while (!Serial);

  Serial.println("--- IoT Lab: Initializing Sense Plus IMU ---");

  // 1. HARDWARE POWER MANAGEMENT
  // The XIAO nRF52840 disables the IMU by default to conserve battery in IoT applications.
  // We must explicitly pull the dedicated power pin HIGH to boot the sensor.
  pinMode(PIN_LSM6DS3TR_C_POWER, OUTPUT);
  digitalWrite(PIN_LSM6DS3TR_C_POWER, HIGH);
  delay(100); // Allow 100ms for the silicon to power up

  // 2. INTERNAL BUS ROUTING
  // The IMU is wired to a hidden internal I2C bus (Wire1), not the standard external pins.
  Wire1.begin();

  // 3. INITIALIZE LIBRARY WITH EXPLICIT BUS
  // We pass &Wire1 to force the library to look at the internal bus, bypassing default routing bugs.
  if (!lsm6ds.begin_I2C(0x6A, &Wire1)) {
    Serial.println("ERROR: Failed to find LSM6DS3TR-C chip. Check power pin and board selection.");
    while (1) {
      delay(10); // Halt execution
    }
  }

  Serial.println("SUCCESS: IMU Found and Initialized!");

  // 4. SENSOR CONFIGURATION (Optional but good practice for students)
  lsm6ds.setAccelRange(LSM6DS_ACCEL_RANGE_2_G);
  lsm6ds.setGyroRange(LSM6DS_GYRO_RANGE_250_DPS);
  lsm6ds.setAccelDataRate(LSM6DS_RATE_104_HZ);
  lsm6ds.setGyroDataRate(LSM6DS_RATE_104_HZ);
}

void loop() {
  // Create standardized Adafruit sensor event objects
  sensors_event_t accel, gyro, temp;

  // Populate the objects with the latest data from the IMU
  lsm6ds.getEvent(&accel, &gyro, &temp);

  // Print Accelerometer Data (Note: Adafruit outputs in m/s^2, not raw 'g's)
  Serial.print("Accel X: "); Serial.print(accel.acceleration.x, 2);
  Serial.print(" \tY: "); Serial.print(accel.acceleration.y, 2);
  Serial.print(" \tZ: "); Serial.print(accel.acceleration.z, 2);
  Serial.println(" m/s^2");

  // Print Gyroscope Data (Note: Adafruit outputs in rad/s, not degrees per second)
  Serial.print("Gyro  X: "); Serial.print(gyro.gyro.x, 2);
  Serial.print(" \tY: "); Serial.print(gyro.gyro.y, 2);
  Serial.print(" \tZ: "); Serial.print(gyro.gyro.z, 2);
  Serial.println(" rad/s");

  Serial.println("-----------------------------------------");
  delay(500);
}