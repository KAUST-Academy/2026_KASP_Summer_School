void setup() {
  // Start USB serial communication
  Serial.begin(115200);

  // Wait until the Serial Monitor is opened
  while (!Serial) {
    delay(10);
  }

  Serial.println("XIAO nRF52840 Sense is connected!");
}

void loop() {
  Serial.println("Hello from the XIAO");
  delay(1000);
}
