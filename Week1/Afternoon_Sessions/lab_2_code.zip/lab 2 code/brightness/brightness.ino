#define LED_PIN 21

void setup() {
  // Set the pin as an output
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  // Fade IN: We count DOWN from 255 (Off) to 0 (Fully On)
  for (int brightness = 255; brightness >= 0; brightness--) {
    analogWrite(LED_PIN, brightness);
    delay(10); // Adjust this delay to change the fade speed
  }

  delay(1000); // Hold at maximum brightness

  // Fade OUT: We count UP from 0 (Fully On) to 255 (Off)
  for (int brightness = 0; brightness <= 255; brightness++) {
    analogWrite(LED_PIN, brightness);
    delay(10);
  }

  delay(1000); // Hold while off before repeating
}