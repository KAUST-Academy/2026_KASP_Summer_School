#include <Wire.h>

#define IMU_ADDRESS 0x6A
#define WHO_AM_I_REG 0x0F
#define CTRL1_XL 0x10 // Accelerometer control register
#define OUTX_L_XL 0x28 // First register of accelerometer data

// Fallback in case the new Plus board package hasn't defined the power pin macro yet
#ifndef PIN_LSM6DS3TR_C_POWER
#define PIN_LSM6DS3TR_C_POWER 14
#endif

void setup() {
  Serial.begin(115200);
  while (!Serial);

  Serial.println("--- BARE METAL IMU TEST ---");
  Serial.println("Powering up the internal bus...");
  
  // Turn on the physical power switch for the IMU
  pinMode(PIN_LSM6DS3TR_C_POWER, OUTPUT);
  digitalWrite(PIN_LSM6DS3TR_C_POWER, HIGH);
  delay(100);

  // Force communication over the hidden internal bus
  Wire1.begin();

  // 1. Ask the IMU for its Hardware ID
  Wire1.beginTransmission(IMU_ADDRESS);
  Wire1.write(WHO_AM_I_REG);
  Wire1.endTransmission(false);
  Wire1.requestFrom((uint8_t)IMU_ADDRESS, (uint8_t)1);
  
  if (Wire1.available()) {
    uint8_t whoAmI = Wire1.read();
    Serial.print("SUCCESS! IMU Chip ID found: 0x");
    Serial.println(whoAmI, HEX);
    
    // 2. Turn on the Accelerometer (104 Hz, 2g range)
    Wire1.beginTransmission(IMU_ADDRESS);
    Wire1.write(CTRL1_XL);
    Wire1.write(0x40); 
    Wire1.endTransmission();
    Serial.println("Accelerometer powered on. Reading data...\n");
  } else {
    Serial.println("FAILED: No response from IMU. Hardware may be dead.");
    while(1); // Halt the code here
  }
}

void loop() {
  // 3. Read 6 bytes of raw accelerometer data (X, Y, Z)
  Wire1.beginTransmission(IMU_ADDRESS);
  Wire1.write(OUTX_L_XL);
  Wire1.endTransmission(false);
  Wire1.requestFrom((uint8_t)IMU_ADDRESS, (uint8_t)6);

  if (Wire1.available() == 6) {
    // Combine the high and low bytes for each axis
    int16_t x = Wire1.read() | (Wire1.read() << 8);
    int16_t y = Wire1.read() | (Wire1.read() << 8);
    int16_t z = Wire1.read() | (Wire1.read() << 8);

    // Convert raw data to roughly standard 'g' forces
    float gX = (x * 0.061) / 1000.0;
    float gY = (y * 0.061) / 1000.0;
    float gZ = (z * 0.061) / 1000.0;

    Serial.print("Accel (g) -> X: "); Serial.print(gX, 2);
    Serial.print(" | Y: "); Serial.print(gY, 2);
    Serial.print(" | Z: "); Serial.println(gZ, 2);
  }
  delay(500);
}