#include <ArduinoBLE.h>
#include <LSM6DS3.h>
#include <Wire.h>

#include <TensorFlowLite.h>
#include <tensorflow/lite/micro/all_ops_resolver.h>
#include <tensorflow/lite/micro/micro_error_reporter.h>
#include <tensorflow/lite/micro/micro_interpreter.h>
#include <tensorflow/lite/schema/schema_generated.h>

#include "model.h"

// ====================================================
// IMU gesture-classifier settings
// ====================================================

const float accelerationThreshold = 2.5f;
const int numSamples = 119;
const unsigned long sampleIntervalMs = 10;  // Approximately 100 Hz
int samplesRead = numSamples;

LSM6DS3 myIMU(I2C_MODE, 0x6A);

const char* GESTURES[] = {
  "punch",
  "flex"
};

#define NUM_GESTURES (sizeof(GESTURES) / sizeof(GESTURES[0]))

// ====================================================
// TensorFlow Lite Micro settings
// ====================================================

tflite::MicroErrorReporter tflErrorReporter;
tflite::AllOpsResolver tflOpsResolver;

const tflite::Model* tflModel = nullptr;
tflite::MicroInterpreter* tflInterpreter = nullptr;
TfLiteTensor* tflInputTensor = nullptr;
TfLiteTensor* tflOutputTensor = nullptr;

// Extra room because ArduinoBLE also uses RAM.
constexpr int tensorArenaSize = 16 * 1024;
byte tensorArena[tensorArenaSize] __attribute__((aligned(16)));

// ====================================================
// BLE settings
// ====================================================

const char* BLE_DEVICE_NAME = "Gesture01";
const uint16_t MANUFACTURER_ID = 0xFFFF;
const uint8_t NODE_ID = 1;

uint8_t sequenceNumber = 0;

/*
  Manufacturer-data payload:

  Byte 0: Protocol version
  Byte 1: Node ID
  Byte 2: ASCII gesture code
          'P' = punch = 0x50
          'F' = flex  = 0x46
          'W' = waiting = 0x57
  Byte 3: Selected confidence, 0-100
  Byte 4: Punch confidence, 0-100
  Byte 5: Flex confidence, 0-100
  Byte 6: Sequence number
*/

void Init_BLE()
{
  if (!BLE.begin())
  {
    Serial.println("ERROR: BLE failed to start.");
    while (1)
    {
      delay(1000);
    }
  }

  BLE.setLocalName(BLE_DEVICE_NAME);
  BLE.setDeviceName(BLE_DEVICE_NAME);

  Serial.println("BLE initialized.");
}

uint8_t probabilityToPercent(float probability)
{
  probability = constrain(probability, 0.0f, 1.0f);
  return (uint8_t)(probability * 100.0f + 0.5f);
}

bool Advertise_Gesture(char gestureCode,
                       uint8_t selectedConfidence,
                       uint8_t punchConfidence,
                       uint8_t flexConfidence)
{
  uint8_t payload[7];
  const uint8_t packetNumber = sequenceNumber;

  payload[0] = 1;
  payload[1] = NODE_ID;
  payload[2] = (uint8_t)gestureCode;
  payload[3] = selectedConfidence;
  payload[4] = punchConfidence;
  payload[5] = flexConfidence;
  payload[6] = packetNumber;

  BLE.stopAdvertise();
  delay(20);

  if (!BLE.setManufacturerData(MANUFACTURER_ID, payload, sizeof(payload)))
  {
    Serial.println("ERROR: Could not set BLE manufacturer data.");
    return false;
  }

  if (!BLE.advertise())
  {
    Serial.println("ERROR: BLE advertising could not be started.");
    return false;
  }

  sequenceNumber++;

  Serial.println("----------------------------------------");
  Serial.print("BLE ADVERTISEMENT UPDATED - PACKET #");
  Serial.println(packetNumber);

  Serial.print("Sent classification code: ");
  Serial.println(gestureCode);

  Serial.print("Sent classification: ");
  if (gestureCode == 'P')
  {
    Serial.println("punch");
  }
  else if (gestureCode == 'F')
  {
    Serial.println("flex");
  }
  else
  {
    Serial.println("waiting");
  }

  Serial.print("Selected confidence: ");
  Serial.print(selectedConfidence);
  Serial.println("%");

  Serial.print("Punch: ");
  Serial.print(punchConfidence);
  Serial.print("% | Flex: ");
  Serial.print(flexConfidence);
  Serial.println("%");

  Serial.println("BLE data is now being broadcast.");
  Serial.println("----------------------------------------");

  return true;
}

// ====================================================
// Setup
// ====================================================

void setup()
{
  Serial.begin(115200);

  unsigned long serialWaitStart = millis();
  while (!Serial && millis() - serialWaitStart < 5000)
  {
    delay(10);
  }

  Serial.println();
  Serial.println("Starting IMU gesture classifier with BLE...");

  Wire.begin();

  if (myIMU.begin() != 0)
  {
    Serial.println("ERROR: IMU could not be started.");
    while (1)
    {
      delay(1000);
    }
  }

  Serial.println("IMU started successfully.");

  tflModel = tflite::GetModel(model);

  if (tflModel->version() != TFLITE_SCHEMA_VERSION)
  {
    Serial.println("ERROR: Model schema mismatch.");
    while (1)
    {
      delay(1000);
    }
  }

  tflInterpreter = new tflite::MicroInterpreter(
    tflModel,
    tflOpsResolver,
    tensorArena,
    tensorArenaSize,
    &tflErrorReporter
  );

  Serial.println("Allocating TensorFlow tensors...");

  if (tflInterpreter->AllocateTensors() != kTfLiteOk)
  {
    Serial.println("ERROR: AllocateTensors failed.");
    while (1)
    {
      delay(1000);
    }
  }

  Serial.println("TensorFlow tensors allocated.");

  tflInputTensor = tflInterpreter->input(0);
  tflOutputTensor = tflInterpreter->output(0);

  Init_BLE();
  Advertise_Gesture('W', 0, 0, 0);

  Serial.println("Move the board to perform a punch or flex gesture.");
}

// ====================================================
// Main loop
// ====================================================

void loop()
{
  float aX, aY, aZ;
  float gX, gY, gZ;

  BLE.poll();

  // Wait for significant movement.
  while (samplesRead == numSamples)
  {
    BLE.poll();

    aX = myIMU.readFloatAccelX();
    aY = myIMU.readFloatAccelY();
    aZ = myIMU.readFloatAccelZ();

    float aSum = fabs(aX) + fabs(aY) + fabs(aZ);

    if (aSum >= accelerationThreshold)
    {
      samplesRead = 0;

      // Pause advertising while sampling and running inference.
      BLE.stopAdvertise();

      Serial.println();
      Serial.println("Motion detected.");
      Serial.println("BLE advertising paused.");
      Serial.println("Capturing 119 IMU samples...");
      break;
    }

    delay(5);
  }

  // Capture one full gesture window.
  unsigned long nextSampleTime = millis();

  while (samplesRead < numSamples)
  {
    while ((long)(millis() - nextSampleTime) < 0)
    {
      delay(1);
    }
    nextSampleTime += sampleIntervalMs;

    aX = myIMU.readFloatAccelX();
    aY = myIMU.readFloatAccelY();
    aZ = myIMU.readFloatAccelZ();

    gX = myIMU.readFloatGyroX();
    gY = myIMU.readFloatGyroY();
    gZ = myIMU.readFloatGyroZ();

    tflInputTensor->data.f[samplesRead * 6 + 0] = (aX + 4.0f) / 8.0f;
    tflInputTensor->data.f[samplesRead * 6 + 1] = (aY + 4.0f) / 8.0f;
    tflInputTensor->data.f[samplesRead * 6 + 2] = (aZ + 4.0f) / 8.0f;
    tflInputTensor->data.f[samplesRead * 6 + 3] = (gX + 2000.0f) / 4000.0f;
    tflInputTensor->data.f[samplesRead * 6 + 4] = (gY + 2000.0f) / 4000.0f;
    tflInputTensor->data.f[samplesRead * 6 + 5] = (gZ + 2000.0f) / 4000.0f;

    samplesRead++;
  }

  Serial.println("Capture complete.");
  Serial.println("Starting TensorFlow inference...");

  TfLiteStatus invokeStatus = tflInterpreter->Invoke();

  if (invokeStatus != kTfLiteOk)
  {
    Serial.println("ERROR: TensorFlow Lite Invoke failed.");

    // Restart waiting advertisement after an inference error.
    Advertise_Gesture('W', 0, 0, 0);
    delay(1000);
    return;
  }

  Serial.println("Inference complete.");

  int bestGestureIndex = 0;
  float bestProbability = tflOutputTensor->data.f[0];

  for (int i = 1; i < NUM_GESTURES; i++)
  {
    float probability = tflOutputTensor->data.f[i];

    if (probability > bestProbability)
    {
      bestProbability = probability;
      bestGestureIndex = i;
    }
  }

  uint8_t punchPercent =
    probabilityToPercent(tflOutputTensor->data.f[0]);

  uint8_t flexPercent =
    probabilityToPercent(tflOutputTensor->data.f[1]);

  uint8_t selectedPercent =
    probabilityToPercent(bestProbability);

  char gestureCode = (bestGestureIndex == 0) ? 'P' : 'F';

  Serial.println();
  Serial.println("========================================");
  Serial.print("CLASSIFICATION: ");
  Serial.println(GESTURES[bestGestureIndex]);

  Serial.print("BLE CODE: ");
  Serial.println(gestureCode);

  Serial.print("CONFIDENCE: ");
  Serial.print(selectedPercent);
  Serial.println("%");

  Serial.print("Punch probability: ");
  Serial.print(punchPercent);
  Serial.print("% | Flex probability: ");
  Serial.print(flexPercent);
  Serial.println("%");
  Serial.println("========================================");

  Serial.println("Updating BLE advertisement...");

  if (!Advertise_Gesture(
        gestureCode,
        selectedPercent,
        punchPercent,
        flexPercent))
  {
    Serial.println("BLE SEND FAILED: classification was not advertised.");
  }
  else
  {
    Serial.println("BLE SEND COMPLETE.");
  }

  Serial.println("Ready for the next gesture.");
  Serial.println();

  delay(300);
}
