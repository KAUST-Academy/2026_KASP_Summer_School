/*
  XIAO ESP32S3 BLE Gesture Receiver

  Receives BLE manufacturer data only from the transmitter named exactly:

      Gesture01

  Transmitter payload:
    Byte 0-1: Company ID = 0xFFFF
    Byte 2:   Protocol version = 1
    Byte 3:   Node ID = 1
    Byte 4:   'P', 'F', or 'W'
    Byte 5:   Selected confidence
    Byte 6:   Punch confidence
    Byte 7:   Flex confidence
    Byte 8:   Sequence number

  Arduino IDE:
    Board: Seeed Studio XIAO ESP32S3
    USB CDC On Boot: Enabled
    Serial Monitor: 115200 baud
*/

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEScan.h>
#include <BLEAdvertisedDevice.h>

// ====================================================
// Exact transmitter identity
// ====================================================

const char* TARGET_DEVICE_NAME = "Gesture01";

const uint16_t EXPECTED_COMPANY_ID = 0xFFFF;
const uint8_t EXPECTED_PROTOCOL_VERSION = 1;
const uint8_t EXPECTED_NODE_ID = 1;

const uint32_t SCAN_TIME_SECONDS = 4;

BLEScan* pBLEScan = nullptr;

bool targetFound = false;
bool havePreviousPacket = false;
uint8_t previousSequenceNumber = 0;

// ====================================================
// Helpers
// ====================================================

const char* gestureName(char code)
{
  if (code == 'P') return "Punch";
  if (code == 'F') return "Flex";
  if (code == 'W') return "Waiting";
  return "Unknown";
}

bool validGestureCode(char code)
{
  return code == 'P' || code == 'F' || code == 'W';
}

void blinkStartupLED()
{
  // XIAO ESP32S3 onboard yellow LED is active LOW.
  pinMode(LED_BUILTIN, OUTPUT);

  for (int i = 0; i < 3; i++)
  {
    digitalWrite(LED_BUILTIN, LOW);
    delay(150);
    digitalWrite(LED_BUILTIN, HIGH);
    delay(150);
  }
}

// ====================================================
// BLE callback
// ====================================================

class GestureReceiverCallbacks : public BLEAdvertisedDeviceCallbacks
{
  void onResult(BLEAdvertisedDevice device) override
  {
    // The receiver must see the exact module name.
    if (!device.haveName())
    {
      return;
    }

    String receivedName = device.getName();

    if (receivedName != TARGET_DEVICE_NAME)
    {
      return;
    }

    targetFound = true;

    if (!device.haveManufacturerData())
    {
      Serial.println("Gesture01 found, but manufacturer data is not present yet.");
      return;
    }

    String manufacturerData = device.getManufacturerData();

    if (manufacturerData.length() < 9)
    {
      Serial.print("Gesture01 packet is too short: ");
      Serial.print(manufacturerData.length());
      Serial.println(" bytes");
      return;
    }

    const uint8_t* data =
      reinterpret_cast<const uint8_t*>(manufacturerData.c_str());

    uint16_t companyID =
      (uint16_t)data[0] |
      ((uint16_t)data[1] << 8);

    uint8_t protocolVersion = data[2];
    uint8_t nodeID = data[3];
    char gestureCode = (char)data[4];
    uint8_t selectedConfidence = data[5];
    uint8_t punchConfidence = data[6];
    uint8_t flexConfidence = data[7];
    uint8_t sequenceNumber = data[8];

    // Validate that this is our expected packet.
    if (companyID != EXPECTED_COMPANY_ID)
    {
      return;
    }

    if (protocolVersion != EXPECTED_PROTOCOL_VERSION)
    {
      return;
    }

    if (nodeID != EXPECTED_NODE_ID)
    {
      return;
    }

    if (!validGestureCode(gestureCode))
    {
      return;
    }

    // Avoid printing the same advertisement repeatedly.
    if (havePreviousPacket &&
        sequenceNumber == previousSequenceNumber)
    {
      return;
    }

    havePreviousPacket = true;
    previousSequenceNumber = sequenceNumber;

    Serial.println();
    Serial.println("========================================");
    Serial.print("Module: ");
    Serial.println(receivedName);

    Serial.print("Address: ");
    Serial.println(device.getAddress().toString().c_str());

    Serial.print("RSSI: ");
    Serial.print(device.getRSSI());
    Serial.println(" dBm");

    Serial.print("Gesture code: ");
    Serial.println(gestureCode);

    Serial.print("Classification: ");
    Serial.println(gestureName(gestureCode));

    Serial.print("Selected confidence: ");
    Serial.print(selectedConfidence);
    Serial.println("%");

    Serial.print("Punch confidence: ");
    Serial.print(punchConfidence);
    Serial.println("%");

    Serial.print("Flex confidence: ");
    Serial.print(flexConfidence);
    Serial.println("%");

    Serial.print("Packet number: ");
    Serial.println(sequenceNumber);
    Serial.println("========================================");
  }
};

// ====================================================
// Setup
// ====================================================

void setup()
{
  Serial.begin(115200);

  // Give the native USB serial port time to appear.
  delay(3000);

  blinkStartupLED();

  Serial.println();
  Serial.println("========================================");
  Serial.println("XIAO ESP32S3 BLE Gesture Receiver");
  Serial.print("Filtering exact module name: ");
  Serial.println(TARGET_DEVICE_NAME);
  Serial.println("========================================");

  Serial.println("Starting BLE...");

  BLEDevice::init("");

  pBLEScan = BLEDevice::getScan();

  // Active scanning is needed to receive the scan response,
  // which may contain the complete device name.
  pBLEScan->setActiveScan(true);

  // true allows repeated packets. Sequence number removes duplicates.
  pBLEScan->setAdvertisedDeviceCallbacks(
    new GestureReceiverCallbacks(),
    true
  );

  pBLEScan->setInterval(100);
  pBLEScan->setWindow(99);

  Serial.println("BLE scanner started.");
}

// ====================================================
// Main loop
// ====================================================

void loop()
{
  targetFound = false;

  Serial.println("Scanning for Gesture01...");

  BLEScanResults* results =
    pBLEScan->start(SCAN_TIME_SECONDS, false);

  Serial.print("Total BLE devices seen: ");
  Serial.println(results->getCount());

  if (!targetFound)
  {
    Serial.println("Gesture01 was not detected in this scan.");
  }

  pBLEScan->clearResults();

  delay(500);
}
